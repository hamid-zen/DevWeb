<p><?= $this->nettoyer($msgErreur) ?></p>
